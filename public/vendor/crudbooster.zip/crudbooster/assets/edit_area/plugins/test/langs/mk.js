editArea.add_lang("mk",{
test_select: "select tag",
test_but: "test button"
});
